import { ProductPriceInfo } from './ProductBranchFilters';

export class ProductBranch {
    productId: number;
    branchId: number;
    hasStock: boolean;
    stockQty: number | null;
    updatedAt?: Date | undefined;
    productName?: string | undefined;
    productBarcode?: string | null | undefined;
    productPrices?: ProductPriceInfo[] | undefined;

    constructor(
        productId: number,
        branchId: number,
        hasStock: boolean = false,
        stockQty: number | null = null,
        updatedAt?: Date,
        productName?: string,
        productBarcode?: string | null,
        productPrices?: ProductPriceInfo[]
    ) {
        this.productId = productId;
        this.branchId = branchId;
        this.hasStock = hasStock;
        this.stockQty = stockQty;
        this.updatedAt = updatedAt;
        this.productName = productName;
        this.productBarcode = productBarcode;
        this.productPrices = productPrices;
    }
}
