import { Product } from "../../domain/product/Product";
import { ProductRepository } from "../../domain/product/ProductRepository";

export class GetAllProducts {
    constructor(private repository: ProductRepository) {}

    async run(filters?: { categoryId?: number; brandId?: number; state?: boolean }): Promise<Product[]> {
        return this.repository.getAll(filters);
    }
}
