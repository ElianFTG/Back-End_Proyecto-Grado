import { Product } from "./Product";

export interface ProductRepository {
    getAll(filters?: { categoryId?: number; brandId?: number; state?: boolean }): Promise<Product[]>;
    create(product: Product): Promise<Product | null>;
    findById(id: number): Promise<Product | null>;
    update(id: number, product: Partial<Product>, userId: number): Promise<Product | null>;
    updateState(id: number, userId: number): Promise<void>;
}
