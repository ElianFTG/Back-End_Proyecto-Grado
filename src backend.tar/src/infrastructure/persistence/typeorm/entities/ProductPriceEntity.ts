import { Entity, PrimaryColumn, Column, ManyToOne, JoinColumn, UpdateDateColumn } from 'typeorm';
import { ProductEntity } from './ProductEntity';
import { ClientTypeEntity } from './ClientTypeEntity';

@Entity({ name: 'product_prices' })
export class ProductPriceEntity {
    @PrimaryColumn({ type: 'smallint', unsigned: true })
    product_id!: number;

    @PrimaryColumn({ type: 'smallint', unsigned: true })
    client_type_id!: number;

    @Column({ type: 'decimal', precision: 10, scale: 2 })
    price!: number;

    @UpdateDateColumn({ type: 'timestamp' })
    updated_at!: Date;

    @ManyToOne(() => ProductEntity, product => product.prices, { onDelete: 'CASCADE' })
    @JoinColumn({ name: 'product_id' })
    product!: ProductEntity;

    @ManyToOne(() => ClientTypeEntity, { onDelete: 'RESTRICT' })
    @JoinColumn({ name: 'client_type_id' })
    clientType!: ClientTypeEntity;
}
