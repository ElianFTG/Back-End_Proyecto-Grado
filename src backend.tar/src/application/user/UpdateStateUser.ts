import { UserRepository } from "../../domain/user/UserRepository";
import { canDeleteRole, InsufficientPermissionsError } from "../../domain/user/RolePermissions";

export class UpdateStateUser {
    constructor(private repository: UserRepository) {}

    /**
     * Cambia el estado de un usuario (soft delete) validando permisos
     * @param actorRole - Rol del usuario que está eliminando (obtenido del JWT)
     * @param targetRole - Rol del usuario objetivo
     */
    async run(
        id: number,
        user_id: number,
        actorRole?: string,
        targetRole?: string
    ): Promise<void> {
        // Validar permisos si se proporcionan los roles
        if (actorRole && targetRole) {
            if (!canDeleteRole(actorRole, targetRole)) {
                throw new InsufficientPermissionsError(
                    `No tienes permisos para eliminar usuarios con rol "${targetRole}"`
                );
            }
        }
        
        return this.repository.updateState(id, user_id);
    }
}