import { User } from "../../domain/user/User";
import { UserRepository } from "../../domain/user/UserRepository";
import { canCreateRole, InsufficientPermissionsError } from "../../domain/user/RolePermissions";
import { EmailService } from "../../domain/services/EmailService";
import bcrypt from "bcryptjs";
import { config } from 'dotenv';

config();

function generateUsername(lastName: string, secondLastName: string, ci: string): string {
    const firstInitial = lastName.charAt(0).toUpperCase();
    const secondInitial = secondLastName.charAt(0).toUpperCase();
    const ciClean = ci.replace(/[^a-zA-Z0-9]/g, '').trim();
    return `${firstInitial}${secondInitial}${ciClean}`;
}

export class CreateUser {
    constructor(
        private repository: UserRepository,
        private emailService?: EmailService
    ) {}
    
    async run(
        ci: string,
        names: string,
        lastName: string,
        secondLastName: string,
        role: string,
        branchId: number,
        email: string,
        userId: number,
        actorRole?: string,
    ): Promise<User | null> {
        if (actorRole) {
            if (!canCreateRole(actorRole, role)) {
                throw new InsufficientPermissionsError(
                    `No tienes permisos para crear usuarios con rol "${role}"`
                );
            }
        }
        
        const existingByCi = await this.repository.findByCi(ci);
        if (existingByCi) {
            throw new Error('Ya existe un usuario con este CI');
        }

        if (email) {
            const existingByEmail = await this.repository.findByEmail(email);
            if (existingByEmail) {
                throw new Error('Ya existe un usuario con este correo electrónico');
            }
        }

        const userName = generateUsername(lastName, secondLastName, ci);
        const tempPassword = userName; 
        
        const salt = await bcrypt.genSalt(Number(process.env.SALT));
        const passwordHashed = await bcrypt.hash(tempPassword, salt);
        
        const user = await this.repository.create(
            new User(
                ci,
                names,
                lastName,
                secondLastName,
                email || "",
                role,
                branchId,
                userName,
                true 
            ),
            passwordHashed,
            userId
        );

        if (user && email && this.emailService) {
            try {
                await this.emailService.sendCredentials(email, userName, tempPassword, names);
            } catch (emailError) {
                console.error('Error al enviar correo con credenciales:', emailError);
            }
        }

        return user;
    }
}

