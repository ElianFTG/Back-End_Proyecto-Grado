import { User } from "../../domain/user/User";
import { UserRepository } from "../../domain/user/UserRepository";
import { canEditRole, InsufficientPermissionsError } from "../../domain/user/RolePermissions";

export class UpdateUser {
    constructor(private repository: UserRepository) {}

    /**
     * Actualiza un usuario validando permisos del actor
     * @param actorRole - Rol del usuario que está editando (obtenido del JWT)
     * @param targetCurrentRole - Rol actual del usuario objetivo (para validar permisos)
     */
    async run(
        id: number,
        user: Partial<User>,
        userId: number,
        actorRole?: string,
        targetCurrentRole?: string
    ): Promise<User | null> {
        // Validar permisos si se proporcionan los roles
        if (actorRole && targetCurrentRole) {
            if (!canEditRole(actorRole, targetCurrentRole)) {
                throw new InsufficientPermissionsError(
                    `No tienes permisos para editar usuarios con rol "${targetCurrentRole}"`
                );
            }
        }
        
        // Si se está cambiando el rol, validar que el actor pueda asignar ese nuevo rol
        if (actorRole && user.role) {
            if (!canEditRole(actorRole, user.role)) {
                throw new InsufficientPermissionsError(
                    `No tienes permisos para asignar el rol "${user.role}"`
                );
            }
        }
        
        return this.repository.update(id, user, userId);
    }
}